class mod_compressed_1(object):

    def kw_1(self):
        pass


class mod_compressed_2(object):

    def kw_2(self):
        pass	